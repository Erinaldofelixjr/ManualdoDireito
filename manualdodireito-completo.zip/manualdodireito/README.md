# Manual do Direito Online

Site completo para conteúdo jurídico com CMS integrado, desenvolvido para hospedagem no Netlify.

## 🚀 Características

- **Design Profissional**: Inspirado nos sites Conjur e Dizer o Direito
- **CMS Integrado**: Decap CMS para gerenciamento de conteúdo
- **Responsivo**: Layout adaptável para desktop e mobile
- **SEO Otimizado**: Meta tags, sitemap e robots.txt configurados
- **SSL Ready**: Configuração automática de HTTPS no Netlify
- **Performance**: Otimizado para carregamento rápido

## 📁 Estrutura do Projeto

```
manualdodireito/
├── index.html              # Página principal
├── sobre.html              # Página sobre
├── admin/                  # Painel administrativo do CMS
│   ├── index.html
│   └── config.yml
├── css/
│   └── style.css           # Estilos principais
├── js/
│   └── script.js           # JavaScript funcional
├── images/
│   ├── placeholder-post.jpg
│   └── uploads/            # Diretório para uploads do CMS
├── posts/                  # Posts em Markdown
│   └── 2025-01-15-novo-marco-civil-internet-principais-mudancas.md
├── pages/                  # Páginas estáticas
├── settings/               # Configurações do site
├── netlify.toml            # Configuração do Netlify
├── sitemap.xml             # Mapa do site
├── robots.txt              # Instruções para bots
├── manifest.json           # Manifest PWA
├── _headers                # Headers de segurança
└── README.md               # Este arquivo
```

## 🛠️ Deploy no Netlify

### Método 1: Deploy via Git (Recomendado)

1. **Criar repositório Git:**
   ```bash
   cd manualdodireito
   git init
   git add .
   git commit -m "Initial commit"
   ```

2. **Conectar ao GitHub/GitLab:**
   - Crie um repositório no GitHub ou GitLab
   - Conecte o repositório local ao remoto
   - Faça push dos arquivos

3. **Deploy no Netlify:**
   - Acesse [netlify.com](https://netlify.com)
   - Clique em "New site from Git"
   - Conecte seu repositório
   - Configure:
     - Build command: `echo "Site estático"`
     - Publish directory: `.`
   - Clique em "Deploy site"

### Método 2: Deploy Manual

1. **Compactar arquivos:**
   ```bash
   cd manualdodireito
   zip -r manualdodireito.zip .
   ```

2. **Upload no Netlify:**
   - Acesse [netlify.com](https://netlify.com)
   - Arraste o arquivo ZIP para a área de deploy
   - Aguarde o processamento

## ⚙️ Configuração do CMS

### 1. Ativar Netlify Identity

1. No painel do Netlify, vá em **Site settings > Identity**
2. Clique em **Enable Identity**
3. Em **Registration preferences**, escolha **Invite only**
4. Em **Git Gateway**, clique em **Enable Git Gateway**

### 2. Configurar Domínio Personalizado

1. No painel do Netlify, vá em **Site settings > Domain management**
2. Clique em **Add custom domain**
3. Digite: `manualdodireito.online`
4. Configure os DNS conforme instruído:
   ```
   Tipo: A     Nome: @     Valor: 75.2.60.5
   Tipo: A     Nome: @     Valor: 99.83.190.102
   Tipo: CNAME Nome: www   Valor: [seu-site].netlify.app
   ```

### 3. Configurar SSL

- O SSL será configurado automaticamente pelo Netlify
- Aguarde até 24 horas para propagação completa

### 4. Criar Usuário Admin

1. Vá para `https://manualdodireito.online/admin`
2. Clique em **Sign up** (primeira vez)
3. Verifique o email de confirmação
4. Faça login no painel administrativo

## 📝 Usando o CMS

### Criar Novo Post

1. Acesse `/admin` no seu site
2. Faça login com suas credenciais
3. Clique em **Posts > New Post**
4. Preencha os campos:
   - **Título**: Título do artigo
   - **Slug**: URL amigável (gerado automaticamente)
   - **Data**: Data de publicação
   - **Categoria**: Área do direito
   - **Tags**: Palavras-chave
   - **Imagem**: Imagem destacada
   - **Descrição**: Resumo do post
   - **Conteúdo**: Texto completo em Markdown

### Gerenciar Páginas

- **Sobre**: Edite informações sobre o site
- **Contato**: Configure informações de contato
- **Configurações**: Ajuste configurações gerais do site

## 🎨 Personalização

### Cores e Tipografia

Edite as variáveis CSS em `css/style.css`:

```css
:root {
    --primary-color: #1a365d;    /* Cor principal */
    --accent-color: #3182ce;     /* Cor de destaque */
    --text-primary: #2d3748;     /* Cor do texto */
    /* ... outras variáveis */
}
```

### Layout e Componentes

- **Header**: Modifique em `index.html` e `sobre.html`
- **Footer**: Atualize informações de contato e redes sociais
- **Cards de Posts**: Personalize em `js/script.js`

## 🔧 Funcionalidades

### JavaScript Implementado

- **Menu Mobile**: Navegação responsiva
- **Busca**: Funcionalidade de busca (base implementada)
- **Lazy Loading**: Carregamento otimizado de imagens
- **Animações**: Efeitos de entrada suaves
- **Botão Voltar ao Topo**: Navegação facilitada

### SEO e Performance

- **Meta Tags**: Configuradas para redes sociais
- **Sitemap**: Gerado automaticamente
- **Robots.txt**: Configurado para bots de busca
- **Headers de Segurança**: Implementados via `_headers`
- **PWA Ready**: Manifest configurado

## 📱 Responsividade

O site é totalmente responsivo com breakpoints:

- **Desktop**: > 768px
- **Tablet**: 768px - 480px
- **Mobile**: < 480px

## 🔒 Segurança

### Headers Implementados

- Content Security Policy (CSP)
- X-Frame-Options
- X-XSS-Protection
- Strict-Transport-Security
- X-Content-Type-Options

### Proteção do Admin

- Painel administrativo protegido por autenticação
- Acesso restrito via Netlify Identity
- Headers específicos para área administrativa

## 📊 Analytics e Monitoramento

Para adicionar Google Analytics:

1. Edite `admin/config.yml`
2. Adicione seu ID do Google Analytics em `settings > general > seo > google_analytics`
3. O código será inserido automaticamente

## 🆘 Suporte e Manutenção

### Backup

- Os posts são armazenados em arquivos Markdown no repositório Git
- Faça backup regular do repositório
- Configure deploy automático para atualizações

### Atualizações

- Atualize o Decap CMS periodicamente
- Monitore atualizações de segurança
- Mantenha o conteúdo sempre atualizado

### Troubleshooting

**CMS não carrega:**
- Verifique se o Netlify Identity está ativado
- Confirme se o Git Gateway está habilitado
- Verifique a configuração do `config.yml`

**SSL não funciona:**
- Aguarde até 24 horas para propagação
- Verifique configuração de DNS
- Force renovação no painel do Netlify

**Posts não aparecem:**
- Verifique se estão marcados como `published: true`
- Confirme a estrutura do front matter
- Verifique se estão na pasta `posts/`

## 📞 Contato

Para suporte técnico ou dúvidas sobre implementação, consulte:

- [Documentação do Netlify](https://docs.netlify.com)
- [Documentação do Decap CMS](https://decapcms.org/docs/)
- [Guias de Markdown](https://www.markdownguide.org)

---

**Desenvolvido para Manual do Direito Online**  
*Site profissional para conteúdo jurídico com CMS integrado*

